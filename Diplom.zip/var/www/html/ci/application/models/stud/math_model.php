<?php

/** 
 * Библиотека расчётных функций для проекта
*/
class Math_Model extends CI_Model
{
//************************************
//  PUBLIC
//************************************
    const MATRIX_LEN = 4;     // количество столбцов матрицы
    const MATRIX_HEIGHT = 3;  // количество строк матрицы
    
  public function __construct() 
  {
    parent::__construct();
  }

/**
 * Расчёт корней  СЛАУ
 * @param array $sourcearray - массив 3х4
 */  
  public function euler3x4($sourcearray)
  {
    $rc = true;
    // Шаг 1 приведение к диагональной матрице
    for ($s = 0; $s < self::MATRIX_HEIGHT; $s++) 
    {
        $sourcearray = $this->onelineto1($sourcearray, $s);
        if (is_null($sourcearray))
        {
            $rc = false;
            break;
        }
        for($z = $s+1; $z < self::MATRIX_HEIGHT; $z++) // вычитание единичной строки
        {
            $sourcearray = $this->minus_mul($sourcearray, $z, $s, $s);
        }
    }
    // Шаг 2 решение
    if ($rc) // ответ есть 
    {  // тупо влоб присвоение
        $b3 = $sourcearray[2][3]; // 2=MATRIX_HEIGHT-1 3=MATRIX_LEN-1 x3 = y3/....
        $b2 = $sourcearray[1][3] - $sourcearray[1][2]*$b3; // 2=MATRIX_HEIGHT-1 3=MATRIX_LEN-1 x2 = y3/....
        $b1 = $sourcearray[0][3] - $sourcearray[0][1]*$b2 - $sourcearray[0][2]*$b3; // x1
        $rc = array( 0=>$b1, 1=>$b2, 2=>$b3);
    }
    else
    {
        $rc = null;
    }
    return $rc;
  }
  
//************************************
//  PRIVATE
//************************************
    /**
     * Приведение строки к единичному виду где элемент $a[$strpos][$strpos] = 1
     * @param array $a - матрица 
     * @param int $strpos
     * @return array/null
     */
    private function onelineto1($a,$strpos)
    {
        $rc = null;
        $j = $strpos+1;
        while (($a[$strpos][$strpos] == 0) && (($j+1)<self::MATRIX_HEIGHT)) // избегаение деления на 0
        {
            $a = $this->swapstr($a, $strpos, $j);  // замена строк во избежание деления на 0
            $j++;        
        }
        if (($a[$strpos][$strpos] != 0)) // решение есть возможно
        {                                // приведение строки к виду 1, х2/х1 ,х3/х1, у/х1
            $rc = $this->divide_by($a, $strpos, $strpos); // для 2 ой строки соответственно 0, 1, x3/x2, y/x2
        }
        return $rc;
    }

    

    /**
   * Обмен строк $i и $j
   * @param array $a - матрица 
   * @param int $i
   * @param int $j
   * @return array $a - матрица 
   */
    private function swapstr($a,$i,$j)
    {
        for ($k = 0; $k < self::MATRIX_LEN; $k++) 
        {
          $b = $a[$i][$k];
          $a[$i][$k] = $a[$j][$k];
          $a[$j][$k] = $b;
        }
        return $a;        
    }
    
    
    /**
     * Деление строки на элемент - приведение к единице
     * @param array $a - матрица 
     * @param  int $str  координаты элемента
     * @param  int $pos
     * @return array матрица 
     */
    private function divide_by($a,$str, $pos)
    {
        $divisor = $a[$str][$pos];
        for ($k = 0; $k < self::MATRIX_LEN; $k++) // можно конечно не с 0, но пусть будет так
        {
          $a[$str][$k] = $a[$str][$k] / $divisor;
        }
        return $a;                
    }
    
    private function minus_mul($a,$strfrom, $strsub, $zerocolumn )
    {
        $multiplcator = $a[$strfrom][$zerocolumn];
        for($k = 0; $k < self::MATRIX_LEN; $k++) 
        {
            $a[$strfrom][$k] = $a[$strfrom][$k] - $a[$strsub][$k]*$multiplcator;
        }
        return $a;
    }
}

