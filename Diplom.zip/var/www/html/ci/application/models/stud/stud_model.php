<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Stud_Model extends CI_Model
{
  public function __construct() 
  {
    parent::__construct();
  }
  
  public function grouplist()
  {
    $rc = array();
    $q = $this->db->query(
            "SELECT title as info1,  
                    start_year as info2,  
                    ntotal,
                    npositiv,
                    id_group as id
             FROM stud.group
             ");        
    if ($q->num_rows()>0)
    {
      $rc = $q->result_array();
    }
    return $rc;
  }
  
  public function examinerlist()
  {
    $rc = array();
    $q = $this->db->query(
            "SELECT first_name as info1,
                    second_name as info2,
                    ntotal,
                    npositiv,
                    id_examiner as id
             FROM stud.examiner
             ");        
    if ($q->num_rows()>0)
    {
      $rc = $q->result_array();
    }
    return $rc;
  }
  
  public function subjectlist()
  {
    $rc = array();
    $q = $this->db->query(
            "SELECT title_subject as info1,
                    '...' as info2,
                    ntotal,
                    npositiv,
                    id_subject as id
             FROM stud.subject
             ");        
    if ($q->num_rows()>0)
    {
      $rc = $q->result_array();
    }
    return $rc;
  }
  
  public function clear_all()
  {
    $this->db->query(
          "UPDATE stud.subject
           SET    ntotal = NULL,
                  npositiv = NULL;
           ");
    $this->db->query(
          "UPDATE stud.examiner
           SET    ntotal = NULL,
                  npositiv = NULL;
           ");
    $this->db->query(
          "UPDATE stud.group
           SET    ntotal = NULL,
                  npositiv = NULL;
           ");
    $this->db->query("DELETE FROM stud.exam_expand");
    $this->db->query("DELETE FROM stud.group_expand");
  }
  
  public function calc_group()
  {
      $this->db->query($this->prepare_updt_norma("group"));      
  }
  
  public function calc_examiner()
  {
      $this->db->query($this->prepare_updt_norma("examiner"));      
  }  
  
  public function calc_subject()
  {
      $this->db->query($this->prepare_updt_norma("subject"));      
  }
  
  public function calc_exam_x()
  {
    $this->db->query(
        "INSERT INTO stud.exam_expand (idexamlist,xts,x2,x1,y,badblock)
         SELECT  id_exam_list, sqrt((ex.npositiv/ex.ntotal)*(s.npositiv/s.ntotal)) AS xts, 
        sqrt((ex.npositiv/ex.ntotal)*(s.npositiv/s.ntotal))*exam_number_in_session AS x2,
        sqrt((ex.npositiv/ex.ntotal)*(s.npositiv/s.ntotal))*exam_number_in_session*exam_number_in_session AS x1,
        number_positive_ratings/number_students_in_group as y,
        0
        FROM exam_list e
        INNER JOIN examiner ex ON ex.id_examiner = e.idexaminer
        INNER JOIN stud.subject s ON s.id_subject = e.idsubject"
    );
  }
  
   
  public function calc_group_light()
  {
    $this->db->query(
    "
        INSERT INTO group_expand
      (idgroup_expand, x1x1,x1x2,x1x3,x2x2,x2x3,x3x3,yx1,yx2,yx3,adequate)
      SELECT idgroup,
        sum(x1*x1) as x1x1,
        sum(x1*x2) as x1x2,
        sum(x1*xts) as x1x3,
        sum(x2*x2) as x2x2,
        sum(x2*xts) as x2x3,
        sum(xts*xts) as x3x3,
        sum(y*x1) as yx1,
        sum(y*x2) as yx2,
        sum(y*xts) as yx3,
        0 as adequate
      FROM exam_expand e
      INNER JOIN exam_list elist ON e.idexamlist = id_exam_list
      WHERE e.badblock = 0
      GROUP BY idgroup
    ");
  }

  public function get_group($ngr)
  {
    $rc = array();
    $q = $this->db->query("SELECT * FROM stud.group WHERE id_group=?", array($ngr));
    if ($q->num_rows()>0)
    {
      $rc = $q->result_array()[0];
    }    
    return $rc;
  }
  
  public function get_group_exam($ngr)
  {
    $rc = array();
    $q = $this->db->query(
      "SELECT 
        id_exam_list,
        session_number,
        exam_number_in_session,
        title_subject,
        first_name,
        second_name,
        xts, 
        x1,
        x2,
        ex.y,
        number_positive_ratings,
        number_students_in_group,
        badblock,
        y_star
       FROM exam_list e 
       INNER JOIN exam_expand ex ON e.id_exam_list = ex.idexamlist
       INNER JOIN examiner t ON e.idexaminer = t.id_examiner
       INNER JOIN subject s ON e.idsubject = s.id_subject
       WHERE idgroup=?
       ORDER BY session_number,
        exam_number_in_session",
       array($ngr));
    if ($q->num_rows()>0)
    {
      $rc = $q->result_array();
    }    
    return $rc;
  }
  
  public function getgroupfull($ngr)
  {
    $rc = array();
    $q = $this->db->query("
        SELECT *
        FROM stud.group g
        INNER JOIN group_expand ge ON g.id_group = ge.idgroup_expand
        WHERE id_group = ?", array($ngr));
    if ($q->num_rows()>0)
    {
      $rc = $q->result_array()[0];
    }    
    return $rc;    
  }
  
  public function update_b($ngr, $koeff_b)
  {
      $q = $this->db->query("
          UPDATE stud.group_expand
          SET b1 = ?,
              b2 = ?,
              b3 = ?
           WHERE idgroup_expand = ?;
          ", array($koeff_b[0],$koeff_b[1],$koeff_b[2],$ngr));
  }
  
  public function set_y_star($ngr, $koeff_b)
  {
      $q = $this->db->query("
          UPDATE stud.group_expand
          SET b1 = ?,
              b2 = ?,
              b3 = ?
           WHERE idgroup_expand = ?;
          ", array($koeff_b[0],$koeff_b[1],$koeff_b[2],$ngr));
  }

  //*******************************
  //* PRIVATE
  //*******************************
  private function prepare_updt_norma($table)
  {
      return
      "UPDATE stud.".$table.
         " SET npositiv = (select sum(stud.exam_list.number_positive_ratings) 
                from stud.exam_list where stud.exam_list.id".$table." = id_".$table."),
              ntotal = (select sum(stud.exam_list.number_students_in_group) 
                from stud.exam_list where stud.exam_list.id".$table." = id_".$table.")";
  }
}