<?php

/* 
 * full_foot.php - Краткое описание 
 *
 * Copyright 2018 ymenshov.
 * 02.08.2018 Версия 1
 *
 * Полное описание файла
 */
?>
  </body>
</html>
