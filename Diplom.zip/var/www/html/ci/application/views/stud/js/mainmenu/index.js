function showPage(pagedata)
{
  VBODY.innerHTML="<iframe src='mainmenu/"+pagedata+"'></iframe>";
}
