<?php
require_once APPPATH.'core/main_controller.php';

/**
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * 
 * @property Stud_Model $stud_model
 */
class MainMenu extends Main_Controller
{
//***********************************
//  P U B L I C
//***********************************
    const MAX_RUN_STEPS = 6;

    public function __construct() 
  {
    parent::__construct();
    $this->load->model("stud/stud_model", "stud_model");
  }
  
  public function index()
  {
    $this->load->view('stud/views/mainmenu/index');
  }
  
  public function grouplist()
  {
      $a[] = array("Группа","Год набора","Сдавало","Сдало","Норма");
      $b = $this->stud_model->grouplist();
      $data_vew['STRLIST'] = array_merge($a,$b);
      $data_vew['HREF']="showexam/";
      $this->load->view('stud/views/mainmenu/unilist',$data_vew);
      return Main_Controller::OUTPUT_MIN;
  }
  
  public function examinerlist()
  {
      $a[] = array("Фамилия","Имя","Сдавало","Сдало","Норма");
      $b = $this->stud_model->examinerlist();
      $data_vew['STRLIST'] = array_merge($a,$b);
      $this->load->view('stud/views/mainmenu/unilist',$data_vew);
      return Main_Controller::OUTPUT_MIN;
  }
  
  public function subjectlist()
  {
      $a[] = array("Предмет","Кратко","Сдавало","Сдало","Норма");
      $b = $this->stud_model->subjectlist();
      $data_vew['STRLIST'] = array_merge($a,$b);
      $this->load->view('stud/views/mainmenu/unilist',$data_vew);
      return Main_Controller::OUTPUT_MIN;
  }

  public function runcalc($stepno = 0)
  {
      switch ($stepno) {
          case 0:
              $this->stud_model->clear_all();
              break;
          case 1:
              $this->stud_model->calc_group();
              break;
          case 2:
              $this->stud_model->calc_subject();
              break;
          case 3:
              $this->stud_model->calc_examiner();
              break;
          case 4:
              $this->stud_model->calc_exam_x();
              break;
          case 5:
              $this->stud_model->calc_group_light();
              break;
          default:
          $stepno = 999;
              break;
      }
      $stepno++;
      $view_data["PERCENT"] = $stepno/self::MAX_RUN_STEPS;
      $view_data["NEXTSTEP"] = $stepno;
      $view_data["BASE"] = $this->config->base_url();
      $this->load->view('stud/views/mainmenu/runcalc',$view_data);
      return Main_Controller::OUTPUT_NONE;
  }
  
  public function showexam($ngr)
  {
      $data_view['GROUP'] = $this->stud_model->get_group($ngr); 
      $data_view['ALLEXAM'] = $this->stud_model->get_group_exam($ngr); 
      $this->load->view('stud/views/mainmenu/showexam',$data_view);
      return Main_Controller::OUTPUT_MIN;
  }
  
  public function groupfull($ngr)
  {
      $this->load->model("stud/math_model", "math_model");
      $grf = $this->stud_model->getgroupfull($ngr);
      $matrix[] = array($grf["x1x1"],$grf["x1x2"],$grf["x1x3"],$grf["yx1"]);
      $matrix[] = array($grf["x1x2"],$grf["x2x2"],$grf["x2x3"],$grf["yx2"]);
      $matrix[] = array($grf["x1x3"],$grf["x2x3"],$grf["x3x3"],$grf["yx3"]);
      $rez = $this->math_model->euler3x4($matrix);
      $this->stud_model->update_b($ngr, $rez);
      echo '<pre>';
      var_dump($grf);
      var_dump($rez);
  }

    /**
   * Проверка метода эйлера
   * результаты решения 
     х1=2.9090909090909
     х2=1.1818181818182
     х3=-1.0909090909091
   */
  public function test()
  {
      /**
       * @var Math_Model math_model Description
       */
      $az[] = array(3,4,5,8);
      $az[] = array(1,7,2,9);
      $az[] = array(6,1,7,11);
      echo '<pre>';
      $this->load->model("stud/math_model", "math_model");
      $rez = $this->math_model->euler3x4($az);
      var_dump($rez);
  }
  
}